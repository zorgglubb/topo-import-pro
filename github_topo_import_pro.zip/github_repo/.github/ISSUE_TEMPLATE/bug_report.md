---
name: Rapport de bug
about: Signaler un problème pour nous aider à améliorer le plugin
title: '[BUG] '
labels: bug
assignees: ''
---

## Description du bug

_Description claire et concise du problème._

## Comment reproduire

Étapes pour reproduire le comportement :
1. Aller dans l'onglet '...'
2. Cliquer sur '...'
3. Voir l'erreur

## Comportement attendu

_Description de ce qui devrait se passer normalement._

## Captures d'écran

_Si applicable, ajouter des captures d'écran._

## Environnement

- **Version QGIS** : (ex: 3.40.9 Bratislava) — Menu `À propos de QGIS`
- **Système d'exploitation** : (Windows 10/11, Ubuntu 22.04, macOS 14…)
- **Version Python** : (visible dans `À propos de QGIS`)
- **Version TopoImport Pro** : (ex: 1.3.0)

## Message d'erreur complet

```
Coller ici le message d'erreur depuis :
QGIS → Affichage → Panneaux → Journal des messages → onglet Python
```

## Fichier exemple

_Si le bug est lié à un fichier spécifique, joindre un exemple (anonymisé si nécessaire)._
