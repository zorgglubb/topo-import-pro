---
name: Demande de fonctionnalité
about: Proposer une idée pour améliorer TopoImport Pro
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## Fonctionnalité souhaitée

_Description claire et concise de ce que vous aimeriez avoir._

## Contexte et besoin

_Pourquoi cette fonctionnalité serait utile ? Dans quel contexte de travail ?_

## Solution envisagée

_Description de la solution que vous imaginez._

## Alternatives considérées

_Autres solutions ou fonctionnalités alternatives envisagées._

## Informations complémentaires

_Tout autre contexte, captures d'écran, exemples de fichiers ou de calculs._
